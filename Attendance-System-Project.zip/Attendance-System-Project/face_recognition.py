import numpy as np
import cv2
import tensorflow as tf
model=tf.keras.models.load_model('models/face_recognition_model.h5') 
def recognize_face(image_path):
    img=cv2.imread(image_path)
    img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    img=cv2.resize(img,(128,128))
    img=np.array(img).reshape(1,128,128,1)
    predictions=model.predict(img)
    student_id=np.argmax(predictions)
    confidence=np.max(predictions)
    return student_id,confidence